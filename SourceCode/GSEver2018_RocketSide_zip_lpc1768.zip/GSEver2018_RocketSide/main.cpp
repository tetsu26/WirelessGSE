// GSE無線化のために書いたソフトウェアです
// 質問は7期電子班長天野まで moai26@outlook.com
// 自由に改変して使ってください
//

#include<mbed.h>
#include<IM920.h>

#define IM920_TX p13
#define IM920_RX p14
#define IM920_BUSY p11
#define IM920_RESET p12
#define IM920_SERIAL_BANDRATE 19200//im920の通信レート

//LED&SWITCHたち      
DigitalOut myled(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);
DigitalOut fill(p21);
DigitalOut dump(p22);
DigitalOut oxy(p23);
DigitalOut fire(p24);

IM920 im920(p13, p14, p11, p12,19200);//無線通信用のserialクラス
Serial pc(USBTX, USBRX);

char send_data[8];    //送信するデータを格納する変数
char recv_data[8];    //受信すry)
int fill_count = 0;     //fillの割り込みの回数を数えるやつ
int oxy_count = 0;     //oxyの割り込みの回数を数えるやつ

//Im920.sendData(send_data,strlen(send_data));         im920ライブラリの使い方

//関数s

void callback () {
    int i;
    int fire_count = 0;
    
    i = im920.recv(recv_data, 8);
    recv_data[i] = 0;
    printf("recv: '%s' (%d)\r\n", recv_data, i);
    
    if (recv_data[0] == '5' || recv_data[7] == '5')     //きちんとデータを受け取れたか確認
    {
        fill = recv_data[1] - '0';           
        dump = recv_data[2] - '0';
        oxy = recv_data[3] - '0';
        fire_count = recv_data[4] - '0';
        
        if(fire_count == 1 && oxy == 1){
            fire = 1;
        }else{
            fire = 0;
        }
        
    }
    /*
    for(int i = 0; i < 8; i++)
    {
        send_data[i] = recv_data[i];
    }
    */
    im920.sendData(recv_data,8);
    //printf("send!!:%s\r\n",recv_data);
}

void fillcount()    //受信割り込みの回数を数える関数
{
    if(fill == 1)
    {
        fill_count += 1;
    }else{
        fill_count = 0;
    }
    
    if(oxy == 1)
    {
        oxy_count += 1;
    }else{
        oxy_count = 0;
    }
    
    printf("fill_count: %d\r\n",fill_count);
    printf("oxy_count: %d\r\n",oxy_count);
    if(fill_count >= 60)
    {
        fill = 0;
        dump = 1;
        printf("recovery mode!!! Dump 30second\r\n");
        wait(30);
        printf("reboot!!");
        NVIC_SystemReset(); 
        
    }
    if(oxy_count >= 60)
    {
        oxy = 0;
        printf("recovery mode!!!\r\n");
        printf("reboot!!");
        NVIC_SystemReset(); 
    }
    
}

int main()
{
    
    pc.baud(115200);
    pc.printf("*** IM920\r\n");
    
    /* 受信側との接続を確立する */
    
    im920.init();

    im920.attach(callback);
    myled = 1;          //設定完了の合図
    
    Ticker fill_limit;
    fill_limit.attach(&fillcount,1);
    
    im920.poll();
    
    
    while(1){
       im920.poll();
       //wait_ms(1);
    }
    
}

     