// GSE無線化のために書いたソフトウェアです
// 質問は7期電子班長天野まで moai26@outlook.com
// 自由に改変して使ってください
/*----------------------------------------------------------
    このプログラムの方針
    im920の受信は割り込み処理によって行われる...
    どのタイミングで送信すればうまくいくのだろうか...
    →受信のときに送信すればええやん！
    でもこうすると一回通信が途絶えると死ぬ...
    →割り込みが入った回数を数えて一定時間割り込みがなかったら送信すればええやん！
------------------------------------------------------------*/

// コントローラ側のソースコードはこの下に続いています

#include<mbed.h>
#include<IM920.h>
#include<cstring>

#define IM920_TX p13
#define IM920_RX p14
#define IM920_BUSY p11
#define IM920_RESET p12
#define IM920_SERIAL_BANDRATE 19200//im920の通信レート

//LED&SWITCHたち     
DigitalOut myled(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);
DigitalOut led_fill(p16);
DigitalOut led_dump(p18);
DigitalOut led_oxy(p20);
DigitalOut led_fire(p21);
DigitalOut led_1(p24);
DigitalOut led_2(p23);
PwmOut buzzer(p26);

DigitalIn fill(p15);
DigitalIn dump(p17);
DigitalIn oxy(p19);
DigitalIn fire(p22);

IM920 im920(p13, p14, p11, p12,19200);//無線通信用のserialクラス
Serial pc(USBTX, USBRX);

// グローバルな奴ら
char send_data[8];    //送信するデータを格納する変数
char recv_data[8];    //受信すry)
int cb_count = 0;     //割り込み回数を数えるやつ
int i = 0;            //一秒間隔で赤いLEDを点滅させるのに使う


//関数s

int fire_buzzer(int i)
{
    if(i == 1)
    {
        buzzer.period(1.0/440.0);  //多分"ラ"
        buzzer.write(0.5f);
        wait(0.5f);
        buzzer.write(0.0f);
    }
    
    return 0;
}

void callback () {  //受信時の割り込み関数（受信したときに送信するコード）
    int i;

    cb_count++; //割り込みの回数を数える変数
    
    i = im920.recv(recv_data, 8);
    recv_data[i] = 0;
    pc.printf("recv: '%s' (%d)\r\n", recv_data, i);
    
    if (recv_data[0] == '5' || recv_data[7] == '5')     //きちんとデータを受け取れたか確認
    {
        led_fill = recv_data[1] - '0';           
        led_dump = recv_data[2] - '0';
        led_oxy = recv_data[3] - '0';
        led_fire = recv_data[4] - '0';
        fire_buzzer(led_fire);
    }
    //8文字1セットで送ることにする
    send_data[0] = '5';   //データ始まりの合図
    send_data[1] = '0'+(fill.read()^ 1);      //プルアップしてるからHiとLoを反転
    send_data[2] = '0'+(dump.read()^ 1);
    send_data[3] = '0'+(oxy.read()^ 1);
    send_data[4] = '0'+(fire.read()^ 1);
    // 5~6はとりあえず未使用
    send_data[5] = '0';
    send_data[6] = '0';
    send_data[7] = '5';   //データ終わりの合図
        
    im920.sendData(send_data,8);    //8文字送りますよーってやつ
    //pc.printf("send:%s\r\n cb_count:%d\r\n",send_data,cb_count);
        
    
}

void callback2()    //受信割り込みの回数を数える関数
{
    
    if(cb_count == 0)
    {
        pc.printf("yabame\r\n");
        NVIC_SystemReset();         //一秒間に一回も通信しなかったらリセットする
        
    }
    else
    {
        cb_count = 0;
        if(i == 0)
        {
            led_2 = 1;
            i++;
        }else{
            led_2 = 0;
            i = 0;
        }
            
        
    }
}



int main()
{
    //各スイッチをプルアップする
    fill.mode(PullUp);
    dump.mode(PullUp);
    oxy.mode(PullUp);
    fire.mode(PullUp);          

    
    im920.init();
    //Im920受信の割り込みを設定
    im920.attach(callback);
    pc.baud(115200);
    pc.printf("Wireless GSE controll system started!!\r\n");
    
    Ticker timeout;
    timeout.attach(&callback2,1);
    
    myled = 1;  //設定完了の合図
    led_1 = 1; 
    im920.poll();
    im920.sendData(send_data,8);    
    
    while(1){   
        im920.poll();//双方向送受信に必要らしい
       // wait_ms(1);  //意味なさそうだけどあると安定する
        
    }
    
}